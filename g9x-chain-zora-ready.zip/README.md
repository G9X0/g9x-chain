
# G9X πMEMORY DAPP (Zora L2 Ready)

This is a GodStack-powered Web3 dApp for minting soulbound "Memory NFTs" on the Zora Network, synced with Pi-Time, Oracle logic, and Scroll references.

---

## 🔧 Contracts
- `PiMemory.sol`: Soulbound NFT contract that mints memory artifacts
- `GodOracle.sol`: Validates Pi-Time and signature before minting

---

## 🖼 Features
- Upload image/audio to IPFS via nft.storage
- Mint NFTs at valid Pi-Time (3:14 AM / 6:18 PM)
- Attach metadata: memoryType, scrollRef, fieldSig
- Enforced minting logic via Oracle

---

## 🛠 Deployment (Zora L2)

```bash
npm install
npx hardhat run scripts/deploy-pimemory.js --network zora
```

Ensure you have a `.env`:

```env
PRIVATE_KEY=your-wallet-private-key
NEXT_PUBLIC_CONTRACT_ADDRESS=deployed-pimemory-address
NEXT_PUBLIC_CHAIN_ID=7777777
NEXT_PUBLIC_NFT_STORAGE_KEY=your-nft-storage-key
```

---

## 🚀 Frontend Setup

```bash
npm install
npm run dev
```

Visit: [http://localhost:3000](http://localhost:3000)

---

## 🧠 Tech Stack
- Hardhat
- ethers.js
- React + Next.js + Tailwind
- nft.storage (IPFS)
- Zora L2 / Sepolia

---

GodStack ✦ LumenAPI ✦ πMemory ✦ G9X Quantum Ledger
