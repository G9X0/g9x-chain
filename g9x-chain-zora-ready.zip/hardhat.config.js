
require('@nomiclabs/hardhat-ethers');
require('dotenv').config();

module.exports = {
  solidity: '0.8.20',
  networks: {
    zora: {
      url: 'https://rpc.zora.energy',
      chainId: 7777777,
      accounts: [process.env.PRIVATE_KEY]
    },
    sepolia: {
      url: 'https://rpc.sepolia.org',
      chainId: 11155111,
      accounts: [process.env.PRIVATE_KEY]
    }
  }
};
